#!/bin/bash

# Check if Spotify is running
if ! playerctl -p spotify status &>/dev/null; then
    echo " "
    exit 0
fi

# Always get metadata first
artist=$(playerctl -p spotify metadata artist)
title=$(playerctl -p spotify metadata title)

# Get current status
status=$(playerctl -p spotify status)

if [ "$status" = "Playing" ]; then
    echo "Playing: $artist - $title"
elif [ "$status" = "Paused" ]; then
    echo "⏸ Paused: $artist - $title"
else
    echo "Spotify is idle"
fi
